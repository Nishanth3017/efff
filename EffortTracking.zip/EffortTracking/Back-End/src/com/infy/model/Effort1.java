package com.infy.model;


public class Effort1 {
private Integer empId;
private Integer effort;
public Integer getEmpId() {
	return empId;
}
public void setEmpId(Integer empId) {
	this.empId = empId;
}
public Integer getEffort() {
	return effort;
}
public void setEffort(Integer effort) {
	this.effort = effort;
}
}
